<?php
return [
    'host' => '127.0.0.1',
    'database' => 'baranganeh',
    'user' => 'root',
    'password' => '',
];